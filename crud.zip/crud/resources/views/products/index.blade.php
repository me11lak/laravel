<!DOCTYPE html>
<html>
<head>
    <title>Products</title>
</head>
<body>
    <h1>Products</h1>
	<table class="table">
    <thead>
        <tr>
            <th>Title</th>
            <th>Select Type</th>
			<th>Select Activity</th>
			<th>Brief Intro </th>
            <th>Actions</th>
        </tr>
    </thead>
	  <tbody>
    @foreach ($products as $product)
        <tr>
		<td>{{ $product->title }}</td>
		<td>{{ $product->select_type }}</td>
		<td>{{ $product->select_activity }}</td>
        <td>{{ $product->brief_intro }}</td>
        <td><img src="{{ asset('images/'.$product->image) }}" alt="product Image" width="200px"></td>
		<td>
                    <a class="btn btn-primary" href="{{ route('products.edit', $product->id) }}">Edit</a>
                    <form action="{{ route('products.destroy', $product->id) }}" method="POST" style="display: inline">
                        @csrf
                        @method('DELETE')
                        <button class="btn btn-danger" type="submit">Delete</button>
                    </form>
                </td>
    @endforeach
	    </tbody>
</table>

<a class="btn btn-success" href="{{ route('products.create') }}">Create Item</a>

</body>
</html>

