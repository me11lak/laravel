<!DOCTYPE html>
<html>
<head>
    <title>Create Product</title>
</head>
<body>
    <h1>Create Product</h1>
    @if ($errors->any())
        <div>
            <strong>Error:</strong>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
    <form method="POST" action="{{ route('products.store') }}" enctype="multipart/form-data">
        @csrf
        <label for="title">Title:</label><br>
        <input type="text" id="title" name="title"><br>
		
		<label for="select_type">Select Type:</label><br>
        <input type="text" id="select_type" name="select_type"><br>
		
		<label for="select_activity">Select Activity:</label><br>
        <input type="text" id="select_activity" name="select_activity"><br>

        <label for="brief_intro">Brief Intro:</label><br>
        <textarea id="brief_activity" name="brief_intro"></textarea><br>

        <label for="image">Image:</label><br>
        <input type="file" id="image" name="image"><br>

        <button type="submit">Submit</button>
    </form>
</body>
</html>
