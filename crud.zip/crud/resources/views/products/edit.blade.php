<!DOCTYPE html>
<html>
<head>
    <title>Edit Product</title>
</head>
<body>
    <h1>Edit Product</h1>
    @if ($errors->any())
        <div>
            <strong>Error:</strong>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
    <form method="POST" action="{{ route('products.update', $product->id) }}" enctype="multipart/form-data">
        @csrf
        @method('PUT')
        <label for="title">Title:</label><br>
        <input type="text" id="title" name="title" value="{{ $product->title }}"><br>
		
		<label for="select_type">Select Type:</label><br>
        <input type="text" id="select_type" name="select_type" value="{{ $product->select_type }}"><br>
		
		<label for="select_activity">Select Activity:</label><br>
        <input type="text" id="select_activity" name="select_activity" value="{{ $product->select_activity }}"><br>

        <label for="brief_intro">Brief Intro:</label><br>
        <textarea id="brief_intro" name="brief_intro">{{ $product->brief_intro }}</textarea><br>

        <label for="image">Image:</label><br>
        <input type="file" id="image" name="image"><br>

        <button type="submit">Update</button>
    </form>
</body>
</html>
