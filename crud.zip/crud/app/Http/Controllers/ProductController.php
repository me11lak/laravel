<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
  
    public function index()
    {
        $products = Product::all();
        return view('products.index', compact('products'));
    }

    public function create()
    {
        return view('products.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required',
            'select_type' => 'required',
			'select_activity' => 'required',
            'brief_intro' => 'required',
            'image' => 'required|image|mimes:jpeg,jpg|max:2048',
        ]);

		$imageName = time().'.'.$request->image->extension();
		$request->image->move(public_path('images'), $imageName);
		
		$product = new Product();
        $product->title = $request->title;
		$product->select_type = $request->select_type;
		$product->select_activity = $request->select_activity;
        $product->brief_intro = $request->brief_intro;
        $product->image = $imageName;
        $product->save();
		
		return redirect()->route('products.index')->with('success', 'Product created successfully.');
		
    }

    public function show(Product $Product)
    {
        return view('Products.show', compact('Product'));
    }

    public function edit(Product $product)
    {
        return view('products.edit', compact('product'));
    }

    public function update(Request $request, Product $product)
    {
        $request->validate([
            'title' => 'required',
            'select_type' => 'required',
			'select_activity' => 'required',
            'brief_intro' => 'required',
            'image' => 'required|image|mimes:jpeg,jpg|max:2048',
        ]);

        if ($request->hasFile('image')) {
			$imageName = time().'.'.$request->image->extension();
			$request->image->move(public_path('images'), $imageName);
            //$imagePath = $request->file('image')->store('public/images');
            $product->image = $imageName;
        }

        $product->title = $request->title;
        $product->select_type = $request->select_type;
		$product->select_activity = $request->select_activity;
        $product->brief_intro = $request->brief_intro;
        $product->save();

        return redirect()->route('products.index')
            ->with('success', 'Product updated successfully.');
    }

    public function destroy(Product $product)
    {
        $product->delete();
        return redirect()->route('products.index')
            ->with('success', 'Product deleted successfully.');
    }
}
