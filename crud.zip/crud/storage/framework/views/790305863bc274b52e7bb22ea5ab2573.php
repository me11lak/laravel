<!DOCTYPE html>
<html>
<head>
    <title>Create Product</title>
</head>
<body>
    <h1>Create Product</h1>
    <?php if($errors->any()): ?>
        <div>
            <strong>Error:</strong>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <form method="POST" action="<?php echo e(route('products.store')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <label for="title">Title:</label><br>
        <input type="text" id="title" name="title"><br>
		
		<label for="select_type">Select Type:</label><br>
        <input type="text" id="select_type" name="select_type"><br>
		
		<label for="select_activity">Select Activity:</label><br>
        <input type="text" id="select_activity" name="select_activity"><br>

        <label for="brief_intro">Brief Intro:</label><br>
        <textarea id="brief_activity" name="brief_intro"></textarea><br>

        <label for="image">Image:</label><br>
        <input type="file" id="image" name="image"><br>

        <button type="submit">Submit</button>
    </form>
</body>
</html>
<?php /**PATH C:\Users\Hp\Downloads\laravel\crud\resources\views/products/create.blade.php ENDPATH**/ ?>