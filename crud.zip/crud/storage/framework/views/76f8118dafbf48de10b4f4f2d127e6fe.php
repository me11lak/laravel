<!DOCTYPE html>
<html>
<head>
    <title>Products</title>
</head>
<body>
    <h1>Products</h1>
	<table class="table">
    <thead>
        <tr>
            <th>Title</th>
            <th>Select Type</th>
			<th>Select Activity</th>
			<th>Brief Intro </th>
            <th>Actions</th>
        </tr>
    </thead>
	  <tbody>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
		<td><?php echo e($product->title); ?></td>
		<td><?php echo e($product->select_type); ?></td>
		<td><?php echo e($product->select_activity); ?></td>
        <td><?php echo e($product->brief_intro); ?></td>
        <td><img src="<?php echo e(asset('images/'.$product->image)); ?>" alt="product Image" width="200px"></td>
		<td>
                    <a class="btn btn-primary" href="<?php echo e(route('products.edit', $product->id)); ?>">Edit</a>
                    <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="POST" style="display: inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-danger" type="submit">Delete</button>
                    </form>
                </td>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	    </tbody>
</table>

<a class="btn btn-success" href="<?php echo e(route('products.create')); ?>">Create Item</a>

</body>
</html>

<?php /**PATH C:\Users\Hp\Downloads\laravel\crud\resources\views/products/index.blade.php ENDPATH**/ ?>